package com.learning.java.access;

import com.learning.java.test.AccessProtectedA;

public class AccessProtectedB extends AccessProtectedA {
	public static void main(String [] args) {
		AccessProtectedB obj1= new AccessProtectedB();
		obj1.msg();
	}
	

}
