package com.learning.java.test;

public class DoWhileDemo {

	public static void main(String[] args) {
		int x = 1;
		do {
			//this would be executed once
			//even if the condition is false from the start
			System.out.println(x);
			x++;
		} while (x <= 10);
	}

}
