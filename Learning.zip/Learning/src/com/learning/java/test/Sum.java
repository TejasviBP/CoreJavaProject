package com.learning.java.test;

public class Sum {

	//Method Sum with two parameters
	public int sum(int x, int y) {
		return (x+y);
	}
	//Overloaded Method Sum with three parameters
	public int sum(int x, int y, int z) {
		return (x+y+z);
	}
	//Overloaded Method Sum with two parameters having different data type
	public double sum(double x, double y) {
		return (x+y);
	}
	public static void main(String[] args) {
		Sum s1= new Sum();
		System.out.println(s1.sum(10, 15));
		System.out.println(s1.sum(10, 15,20));
		System.out.println(s1.sum(10.5, 15.2));
	}

}
