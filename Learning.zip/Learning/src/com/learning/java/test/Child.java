package com.learning.java.test;

public class Child extends Parent{
	void show() {
		System.out.println("Child Show");
	}

}
