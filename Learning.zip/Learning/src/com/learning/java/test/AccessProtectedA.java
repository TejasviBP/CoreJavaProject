package com.learning.java.test;

public class AccessProtectedA {
	protected void msg() {
		System.out.println("Hello");
	}

}
