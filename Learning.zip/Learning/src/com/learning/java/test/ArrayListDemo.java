package com.learning.java.test;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class ArrayListDemo {

	public static void main(String[] args) {
		// Here ArrayList is the implementation class 
		//and List is an interface 
		//<>-->Generic, this is used to explicitly specify the type of Objects we are about to work on
		List<Integer>arrayListdemo = new ArrayList<Integer>();
		arrayListdemo.add(1);// User inputs so the size of this array list would be determined at run time
		arrayListdemo.add(2);
		arrayListdemo.add(3);
		// Access the List
		
		for(int i=0;i<arrayListdemo.size();i++) {
			System.out.println(arrayListdemo.get(i));
		}
		//arrayListdemo=arrayListdemo.size()
		System.out.println("Using For Enhanced Loop");
		for(Integer i:arrayListdemo) {
			System.out.println(i);
		}
		System.out.println("Using Iterator Interface");
		//Using Iterator
		Iterator<Integer>iterator = arrayListdemo.iterator();
		//iterator.hasNext() nothing just a check on the next availabe object in collection
		while(iterator.hasNext()) {
			System.out.println(iterator.next());
		}
	}

}
