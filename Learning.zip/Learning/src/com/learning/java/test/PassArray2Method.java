package com.learning.java.test;

public class PassArray2Method {
	
	public static void main(String [] args) {
		int arr[]= {3,1,2,5,4,6};// Declaration and Initilization of Array
		
		// passing the array to a function
		//function would provide me the sum of an array
		sum(arr);//Method
	}
	
	public static void sum(int []arr) {
		
		int sum=0;//Local variable
		
		//loop
		for(int i=0;i<arr.length;i++) {
			sum=sum+arr[i];
			//First Iteration sum=0,arr[0]=3, sum =sum+arr[0] , sum=3;
			//Second Iteration sum=3,arr[1]=1, sum =sum+arr[1] , sum=4;
			//Third Iteration sum=4,arr[2]=2, sum =sum+arr[2] , sum=6;
			//fourth Iteration sum=6,arr[3]=5, sum =sum+arr[5] , sum=11;
			//Fifth Iteration sum=11,arr[4]=4, sum =sum+arr[4] , sum=15;
			//Sixth Iteration sum=15,arr[5]=6, sum =sum+arr[5] , sum=21;
		}
		System.out.println("Sum of an Array:"+sum);
		
	}

}
