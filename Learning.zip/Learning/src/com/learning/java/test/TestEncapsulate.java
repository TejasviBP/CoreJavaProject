package com.learning.java.test;

public class TestEncapsulate {

	public static void main(String[] args) {
		Encapsulate cap = new Encapsulate();//object cap created for Encapsulate
		
		cap.setName("Jagan");
		cap.setAge(21);
		cap.setRollno(51);
		
		System.out.println("name ="+cap.getName());
		System.out.println("age ="+cap.getAge());
		System.out.println("RollNo ="+cap.getRollno());
		
		//cap.name= this is not possible because we have encapsulated the data by providing the variables as private and these are accessed only through getters and setters.

	}

}
