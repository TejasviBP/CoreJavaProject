package com.learning.java.test;

public interface Vehicle {
	
	// all the abstract methods for Vehicle Interface.
	void changeGear(int a);
	void speedUp(int a);
	void applyBrakes(int a);

}
