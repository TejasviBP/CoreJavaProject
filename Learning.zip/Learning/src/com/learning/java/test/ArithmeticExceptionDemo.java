package com.learning.java.test;

public class ArithmeticExceptionDemo {

	public static void main(String[] args) {

		try {
			int i= divide(5);
		}catch(ArithmeticException ex) {
			System.out.println("Divide by zero");
		}
		//int i= divide(5);
	}

	static int divide(int a) {
		return (a/0);
	}
}
