package com.learning.java.test;

public class NoArgumentConstructor {

	int num;
	String name;
	
//	//This constructor should get called during object creation
//	NoArgumentConstructor(){
//		System.out.println("Constructor Called");
//	}
	NoArgumentConstructor(int num,String name){
		this.num=num;
		this.name=name;
	}
}
