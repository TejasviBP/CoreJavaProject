package com.learning.java.test;

public class Test {

	public static void main(String[] args) {
//		MountainBike mb = new MountainBike(3,100,25);
//		
//		System.out.println(mb.toString());

//		Shape s1= new Circle("Red",2.5);
//		Shape s2= new Rectangle("Rectangle",2,3);
//		
//		System.out.println(s1.toString());
//		System.out.println(s2.toString());
		// Create an instance of BicycleImplement Concrete Class
		BicycleImplement bicycle = new BicycleImplement();
		bicycle.changeGear(2);
		bicycle.speedUp(3);
		bicycle.applyBrakes(1);
		
		System.out.println("Bicycle Implementation");
		bicycle.print();
		
		BikeImplement bike = new BikeImplement();
		bike.changeGear(2);
		bike.speedUp(3);
		bike.applyBrakes(1);
		
		System.out.println("Bike Implementation");
		bike.print();
	}

}
