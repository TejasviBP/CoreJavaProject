package com.learning.java.test;

public class Rectangle extends Shape{
	
	
	double length;
	double width;
	public Rectangle(String colour, double length,double width) {
		super(colour);//Base Class Constructor
		this.length=length;
		this.width= width;
	}
	
	@Override
	double area() {
		
		return (length*width);
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "Rectangle Colur is"+super.getColour()+"Area of Rectangle is "+area();
	}
	
	
	

}
