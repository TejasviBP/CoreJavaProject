package com.learning.java.test;

public class ArrayImplementation {

	public static void main(String[] args) {
		// declare an array
		int [] arr;
		// alocation memory
		arr= new int[5];
		
		//initialize the elements
		arr[0]=10;
		arr[1]=20;
		arr[2]=30;
		arr[3]=40;
		
		// Accessing the elements
		
		for(int i=0;i<arr.length;i++) {
			System.out.println("Element Value:"+arr[i]);
		}
		System.out.println(arr[5]);
	}

}
