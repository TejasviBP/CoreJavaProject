package com.learning.java.test;

import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

public class LinkedListDemo {

	public static void main(String[] args) {
		//Creation of Linked List
		// Here LinkedList is the implementation class 
		//and List is an interface 
		//<>-->Generic, this is used to explicitly specify the type of Objects we are about to work on
		List<String>string = new LinkedList<String>();//
		//LinkedList<String>string = new LinkedList<String>();//
		//Added the Elements
		string.add("H");
		string.add("Y");
		string.add("M");
		string.add("E");
		
		//Sort the List
		Collections.sort(string);
		//Iterator
		Iterator<String>iterator=string.iterator();
		while(iterator.hasNext()) {
			System.out.println(iterator.next());
		}
//		System.out.println("Before Remove");
//		//Remove the element
//		string.remove(0);
//		string.remove("Y");
//		//Iterator
//		Iterator<String> iterator1 = string.iterator();
//		while (iterator1.hasNext()) {
//			System.out.println(iterator1.next());
//		}
		
	}

}
