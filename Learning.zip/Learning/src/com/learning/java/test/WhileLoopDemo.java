package com.learning.java.test;

public class WhileLoopDemo {

	public static void main(String[] args) {
		int x=1;//declaration of variable
		
		//First check the condition
		//if condition is true then we proceed with logic execution inside while loop
		//It becomes a necessity to provide a valid condition otherwise there may be chances that it can create infinite loop
		while(x<=4) {
			System.out.println(x);
			x++;
		}
		//Infinite loop	
//		while(true) {
//			System.out.println(x);
//		}
	}

}
