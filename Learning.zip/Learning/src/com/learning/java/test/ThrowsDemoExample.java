package com.learning.java.test;

import java.io.IOException;

public class ThrowsDemoExample {

	public static void method() throws IOException {
		System.out.println("exception Propogation");

	}
	public static void methodB() throws IOException {
		// handling of exception is always done throw try an catch
		//Over here we are just propogating the exception assuming some calling method would handle it.
		method();
	}

	public static void main(String []args) {
		//Now the Exception has been caught and meaningful statement has been provided to the user
		//Her we have broken the chain of propogation, so the user should be aware as to when the chain needs to be broken.
		try {
			methodB();
		} catch (IOException e) {
			System.out.println("Exception Handled");
		}finally {
			System.out.println("Finally executed");
		}
	}
}
