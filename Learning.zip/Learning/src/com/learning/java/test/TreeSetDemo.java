package com.learning.java.test;

import java.util.Set;
import java.util.TreeSet;

public class TreeSetDemo {

	public static void main(String[] args) {
		// Here TreeSet is the implementation class 
		//and Set is an interface 
		//<>-->Generic, this is used to explicitly specify the type of Objects we are about to work on
		Set<String>treeSetString = new TreeSet<String>();
		treeSetString.add("A");
		treeSetString.add("A");
		treeSetString.add("A");
		//treeSetString.add(null);//Null Values are not permitted.
		treeSetString.add("D");
		treeSetString.add("C");
		treeSetString.add("B");
		System.out.println(treeSetString);
		for(String set:treeSetString) {
			System.out.println(set);
		}
		treeSetString.remove("B");
		System.out.println("After remove");
		for(String set:treeSetString) {
			System.out.println(set);
		}
		if(treeSetString.contains("A")) {
			System.out.println("Present");
		}else {
			System.out.println("Not Present");
		}
	}

}
