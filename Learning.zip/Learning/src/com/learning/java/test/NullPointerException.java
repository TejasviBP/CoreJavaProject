package com.learning.java.test;

public class NullPointerException {

	public static void main(String[] args) {
		String str= null;// we are creating a string literal str pointing to null string object.
		System.out.println(str.length());
		System.out.println(str.equals("Test"));//null.equals("Test")

	}

}
