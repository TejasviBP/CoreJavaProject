package com.learning.java.test;

public class MountainBike extends Bicycle{

	public int seatHeight;
	
	public MountainBike(int gear, int speed,int seatHeight) {
		super(gear, speed);//First Call, invoking the base class constructor
		this.seatHeight=seatHeight;
		
	}
	// Adding one more method to child class
	public void setHeight(int newValue) {
		seatHeight = newValue;
	}
	@Override
	public String toString() {
		return (super.toString() +"\nseat Height is "+seatHeight);
	}
	

}
