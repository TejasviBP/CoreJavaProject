package com.learning.java.test;

public class ForLoopDemo {

	public static void main(String[] args) {
		for(int x=1;x<=5;x++) {
			System.out.println(x);
		}
//		for(int x=1;x<=5;x++) {
//			System.out.println(x);
//		}
		
		String array[]= {"Hello","Hi","Test","Amit"};
		
		for(int i=0;i<array.length;i++) {
			System.out.println(array[i]);
		}
		
		//Enchanced For Loop
		//Mostly used during collection
		System.out.println("enhanced for loop");
		for(String str:array) {
			System.out.println(str);
		}
	}

}
