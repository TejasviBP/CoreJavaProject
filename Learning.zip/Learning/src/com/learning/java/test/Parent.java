package com.learning.java.test;

public class Parent {

	void show() {
		System.out.println("parent show method");
	}
}
