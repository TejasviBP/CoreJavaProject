package com.learning.java.test;

public class Circle extends Shape{

	double radius;
	public Circle(String colour, double radius) {
		super(colour);//Base Class Constructor
		System.out.println("Circle Constructor Called");
		this.radius= radius;
	}

	@Override
	double area() {
		
		return (3.14* radius*radius);
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "Circle Colur is"+super.getColour()+"Area of Circle is "+area();
	}

}
