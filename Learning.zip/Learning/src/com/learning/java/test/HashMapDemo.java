package com.learning.java.test;

import java.util.HashMap;
import java.util.Map;

public class HashMapDemo {

	public static void main(String[] args) {
		//here Map is the interface
		//HashMap is the implementing class
		//<Integer,String> we are specifying that keys to be of type Integer and Values to be of ype string
		Map<Integer,String>hashmap = new HashMap<Integer,String>();
		hashmap.put(1, "Amit");
		hashmap.put(1, "Joe");
		//Printing the object hashmap
		System.out.println("Value Change");
		System.out.println(hashmap);
		hashmap.put(1, "Amit");
		//Printing the object hashmap
		System.out.println(hashmap);
		System.out.println(hashmap.get(1));
	}

}
