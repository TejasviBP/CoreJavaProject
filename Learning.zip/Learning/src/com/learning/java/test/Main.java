package com.learning.java.test;

public class Main {

	public static void main(String[] args) {
		//If a Parent type refrence refers to parent object then parent show  would be called
		Parent obj1= new Parent();
		obj1.show();
		//If a Parent type refrence refers to child class object then child show  would be called
		Parent obj2 = new Child();
		obj2.show();
	}

}
