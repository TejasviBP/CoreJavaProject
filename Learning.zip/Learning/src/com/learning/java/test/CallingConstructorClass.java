package com.learning.java.test;

public class CallingConstructorClass {

	public static void main(String[] args) {
		NoArgumentConstructor noarg = new NoArgumentConstructor(1,"ganesh");//the default constructor for NoArgumentConstructor is called
		System.out.println(noarg.name);
		System.out.println(noarg.num);

	}

}
