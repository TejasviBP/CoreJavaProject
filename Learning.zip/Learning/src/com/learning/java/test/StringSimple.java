package com.learning.java.test;

public class StringSimple {

	public static void main(String[] args) {
		String str="Test";// creating a string object Test using string literal approach aaa@test
		String str1="Test"; //aaaa@test
		
		String str2= new String("Test");// this would be created in heap but java compiler won't search whether we have this string object present in heap or not
		
		//if we want to compare the references then we use == operator // reference like aaa@test to aaa@test
		if (str == str1) {
			System.out.println("String literal point to same string object");
		} else {
			System.out.println("String literal point to different string object");
		}
		// this compares the values like test with test
		if (str.equals(str1)) {
			System.out.println("String content are same");
		} else {
			System.out.println("String content are different");
		}

		// if we want to compare the references then we use == operator // reference
		// like aaa@test to aaa@test
		if (str == str2) {
			System.out.println("String literal point to same string object");
		} else {
			System.out.println("String literal point to different string object");
		}
		// this compares the values like test with test
		if (str.equals(str2)) {
			System.out.println("String content are same");
		} else {
			System.out.println("String content are different");
		}
	}

}
