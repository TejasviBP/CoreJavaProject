package com.learning.java.test;

public abstract class Shape {

	String colour;
	
	abstract double area();// abstract method
	
	public abstract String toString();

	public Shape(String colour) {
		System.out.println("Shape Constructor Called");
		this.colour = colour;
	}

	public String getColour() {
		return colour;
	}

}
