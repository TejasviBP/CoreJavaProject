package com.learning.java.test;

public class StringManipulation {

	public static void main(String[] args) {
		String str1= "Capgemini";
		System.out.println("Length of String :"+str1.length());
		
		char ch = str1.charAt(4);
		System.out.println("Character :"+ch);
		
		
		System.out.println("String after concatenation:"+str1+"Test");
		
		String str2 = str1+"Test";
		System.out.println("String after concatenation:"+str2);
		
		str1.concat("Test");
		System.out.println("String after concatenation:"+str1.concat("Test"));
		
		System.out.println(str1.contains("ge"));
		
		System.out.println(str1.substring(2));
		
		System.out.println(str1.substring(0,2));

	}

}
