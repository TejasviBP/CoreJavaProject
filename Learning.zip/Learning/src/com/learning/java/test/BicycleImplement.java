package com.learning.java.test;

public class BicycleImplement implements Vehicle{

	int speed;
	int gear;
	@Override// Annotations
	public void changeGear(int a) {
		// TODO Auto-generated method stub
		gear=a;
	}

	@Override
	public void speedUp(int a) {
		// TODO Auto-generated method stub
		speed = speed + a;
	}

	@Override
	public void applyBrakes(int a) {
		// TODO Auto-generated method stub
		speed = speed -a;
	}

	public void print() {
		System.out.println("Bicycle"+"Speed=" + speed + ", gear=" + gear);
	}
	
	

	
}
