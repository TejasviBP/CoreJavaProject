package com.learning.java.test;

public class Bicycle {
	
	public int gear;
	public int speed;
	
	public Bicycle(int gear, int speed) {
		this.gear = gear;
		this.speed = speed;
	}
	
	public void applyBrake(int decreament) {
		speed = speed- decreament;
	}
	
	public void sppedUp(int increament) {
		speed= speed + increament;
	}
	@Override
	public String toString() {
		return ("No of gears are " +gear +"\n"+"speed of the bicycle is " + speed);
	}
}
