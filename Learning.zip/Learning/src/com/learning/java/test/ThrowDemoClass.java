package com.learning.java.test;

public class ThrowDemoClass {

	public static void main(String[] args) {
		try {
			throw new ArithmeticException();// is used from the method body to explicity throw a exception to the calling function
			//onus lies on the calllling function to caught this exception else if exception is not caught the exception would propgate to further calling methods
		}catch(ArithmeticException e) {
			e.printStackTrace();
		}
		

	}

}
