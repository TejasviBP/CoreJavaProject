package com.learning.java.test;

public class Encapsulate {

	private String name;
	private int rollno;
	private int age;
	
	//Getter for Name
	public String getName() {
		return name;
	}
	//Setter fr Name
	public void setName(String name) {
		this.name = name;
	}
	//Getter for Roll no
	public int getRollno() {
		return rollno;
	}
	//Setter fr Roll No
	public void setRollno(int rollno) {
		this.rollno = rollno;
	}
	//Getter for Age
	public int getAge() {
		return age;
	}
	//Setter fr Age
	public void setAge(int age) {
		this.age = age;
	}
}
